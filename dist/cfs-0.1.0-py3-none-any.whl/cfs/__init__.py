# Basic package init; we declare a version. Not strictly needed but useful for

__version__="0.1.0"